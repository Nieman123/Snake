package com.snake.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Snake extends ApplicationAdapter {
	private SpriteBatch batch;
	private Texture headTexture;
    private Texture bodyTexture;
    private OrthographicCamera camera;
    private Rectangle head;
    private int snakeLength;

    public enum GameState {
        RUNNING, PAUSED, STOP
    }
    public enum DirectionState {
        RIGHT, LEFT, UP, DOWN
    }
    public DirectionState direction = DirectionState.RIGHT;
	
	@Override
	public void create () {
		batch = new SpriteBatch();

        //snake images and rectangles
		headTexture = new Texture("images.png");
        bodyTexture = new Texture("images.png");
        head = new Rectangle(400, 240, 20, 20);


        //creating a camera
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        batch.begin();
        batch.setProjectionMatrix(camera.combined);

        batch.draw(headTexture, head.x, head.y);
		batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) direction = DirectionState.RIGHT;
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) direction = DirectionState.LEFT;
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) direction = DirectionState.UP;
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) direction = DirectionState.DOWN;

        switch (direction){
            case RIGHT:
                head.x += 400 * Gdx.graphics.getDeltaTime();
                break;

            case LEFT:
                head.x -= 400 * Gdx.graphics.getDeltaTime();
                break;

            case UP:
                head.y += 400 * Gdx.graphics.getDeltaTime();
                break;

            case DOWN:
                head.y -= 400 * Gdx.graphics.getDeltaTime();
                break;
        }

        if (head.x < 0) head.x = 0;
        if (head.x > camera.viewportWidth - 20) head.x = camera.viewportWidth - 20;
	}
}
